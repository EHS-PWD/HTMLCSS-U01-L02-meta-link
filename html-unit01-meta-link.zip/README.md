# Unit 01: Lesson 2 - Meta and Link Tags

Copy your previous `index.html` file into `student-code/` and follow the instructions to update the `<head>` section.